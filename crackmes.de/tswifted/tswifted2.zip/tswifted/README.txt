Hello, the goal of this challange is to create a working keygen.

Rules:
	+ no patching
	+ no auto-keygenning

All the rest is allowed. Solutions which imply more reversing and understanding are more appreciated, but please do whatever you want.

This likely runs only on 64 bit macos boxes, sorry for that.

If you get stuck, try harder. If you get stuck harder, please hang in the forum and i'll see what i can (or can't) say. I'm openly unable to classify the difficulty of crackmes, so i put 3 but it may be 2 or 4, it depends on the approach you choose to solve it.

have fun,

mrmacete